﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TodoListWebApp.Models
{
    public class SPOList
    {
        public string displayName { get; set; }
        public string Name { get; set; }
        public string user { get; set; }
        public string createdDateTime { get; set; }
        public string weburl { get; set; }
        public string createdBy { get; set; }
        
    }
}